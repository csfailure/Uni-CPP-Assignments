/*
    CH08-320142
    a6_p4
    Kevin Silaj
    k.silaj@jacobs-university.de
*/

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <exception>
#include "Fraction.h"

/** Operator **/

using namespace std;

//doing some tests if the operations are correct or incorrect
//by using test and intheend or result function
//example in test(f > ff) should be incorrect so in the result
//it is incorrect 1 and correct 0 and so on

int main()
{
    int cc = 0;
    int incc = 0;

    Fraction f(3,4);
    Fraction ff(1,4);

    Fraction x;

    try
    {
        Fraction f3("1/0");//incorrect
        incc++;
    }

    catch(string &str){
        cout << str << endl;
        cc++;
    }

    Fraction f4(-14,10);
    f4 = Fraction(-7,5);
    x.test(f4 == Fraction(-7,5));//correct

    return 0;
}
