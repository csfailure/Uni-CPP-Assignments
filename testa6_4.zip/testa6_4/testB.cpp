/*
    CH08-320142
    a6_p4
    Kevin Silaj
    k.silaj@jacobs-university.de
*/

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <exception>
#include "Fraction.h"

/** Relation **/

using namespace std;

//doing some tests if the operations are correct or incorrect
//by using test and intheend or result function
//example in test(f > ff) should be incorrect so in the result
//it is incorrect 1 and correct 0 and so on

int main()
{
    Fraction f(3,4);
    Fraction ff(1,4);

    Fraction x;

    x.test(f < ff); //c
    x.test(f > ff); //inc
    x.test(f <= ff); //c
    x.test(f == ff);
    x.test(f >= ff);
    x.test(f != ff);

    cout<< endl;

    x.intheend();
    return 0;
}
