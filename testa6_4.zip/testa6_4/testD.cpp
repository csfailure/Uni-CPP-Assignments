/*
    CH08-320142
    a6_p4
    Kevin Silaj
    k.silaj@jacobs-university.de
*/

#include <iostream>
#include <exception>
#include <sstream>
#include <algorithm>
#include "Fraction.h"
#include <string>

/** Input Output **/

using namespace std;

//doing some tests if the operations are correct or incorrect
//by using test and intheend or result function
//example in test(f > ff) should be incorrect so in the result
//it is incorrect 1 and correct 0 and so on

int main()
{
    Fraction f(3,4);
    Fraction ff(1,4);

    Fraction x;

    //test output
    stringstream out;
    out << f;
    x.test(out.str() == "13/27"); //incorrect
    stringstream in;

    //test input
    in << "5 5";
    in >> ff;
    x.test(ff == Fraction(5,5)); //correct

    cout<< endl;

    x.intheend();
    return 0;
}
