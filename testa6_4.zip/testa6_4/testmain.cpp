#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <exception>
#include "Fraction.h"

using namespace std;

int main()
{
    Fraction x;

    x.Operator();
    x.Arithmetic();
    x.Relation();
    x.Output();

    return 0;
}
