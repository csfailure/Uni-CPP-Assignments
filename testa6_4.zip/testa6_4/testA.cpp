/*
    CH08-320142
    a6_p4
    Kevin Silaj
    k.silaj@jacobs-university.de
*/

#include <iostream>
#include <string>
#include <sstream>
#include <algorithm>
#include <exception>
#include "Fraction.h"

/** Arithmetic **/

using namespace std;

int main()
{

    Fraction f(3,4);
    Fraction ff(1,4);

    Fraction x;

    x.test(f + ff == Fraction(16,16));
    x.test(f + ff == Fraction(13,16));
    x.test(f - ff == Fraction(9,16));
    x.test(f - ff == Fraction(8,16));
    x.test(f * ff == Fraction(3,16));
    x.test(f * ff == Fraction(13,14));
    x.test(f / ff == Fraction(12,4));
    x.test(f / ff == Fraction(20,15));

    cout<<endl;

    x.intheend();

    return 0;
}
